<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}
$alerta = "";$nomusu="";$perusu = "";
if (isset($_GET['alerta'])) {
    // id index exists
    $alerta = $_GET['alerta'];
}

if(isset($_SESSION["permiso"])){
    $perusu = $_SESSION["permiso"];
    if($perusu >= 50){
        $usuario = $_SESSION["codigo"];
        $nomusu = $_SESSION["usuario"];
    } else if($perusu < 50){
        header("location: ../cuenta");    
    }
} else{
    header("location: logout.php");
}
?>
<!DOCTYPE html>
<html>
        <head>
        <title>Salvador Hairdressing - Intranet: Sección de Descargas</title>
        <?php include "../../componentes/header.php"; ?>
        </head>

        <body data-spy="scroll" data-target="#navbar-scroll">

        <!-- /.preloader -->
        <div id="top"></div>

        <!-- /.parallax full screen background image -->
        <?php include "../../componentes/header2.php"; ?>

                            <!-- /.header paragraph -->
                            <div class="landing-text wow fadeInUp">
                                <p>Sección de Descargas</p>
                            </div>				  
                        </div>
                    </div>
                </div> 
            </div> 
        </div>
        <!-- NAVIGATION -->
        <div id="menu">
            <nav class="navbar-wrapper navbar-default" role="navigation">
                <div id="activo" style="float:left;position: absolute;width:20%;">
                    <ul class="nav navbar-nav">
                            <li><a href="#">Usuario: <?php echo $usuario; ?> </a></li>
                        </ul>
                </div>
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-backyard">
                            <span class="sr-only">Intranet: Sección de Descargas</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--<a class="navbar-brand site-name" href="#top"><img src="images/salvador-logo-wh.jpg" alt="logo"></a>-->
                    </div>

                    <div id="navbar-scroll" class="collapse navbar-collapse navbar-backyard navbar-right">
                        <ul class="nav navbar-nav">
                            <li><a href="#main">Intranet: Sección de Descargas</a></li>
                            <li><a href="/intranet/cp">Volver: Panel de Control</a></li>
                            <li><a href="/intranet/logout.php">Salir de la Intranet</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <!-- /.intro section -->
        <div id="main">
            <div class="container"><br><br>
                <div class="row">

                    <!-- /.intro image -->
                    <div class="col-md-6 intro-pic wow slideInLeft">
                        <img src="/intranet/descargas/componentes/img/Salvador_Descargas2.jpg" alt="image" class="img-responsive">
                    </div>	

                    <!-- /.intro content -->
                    <div class="col-md-6 wow slideInRight">
                        <h2>Descargas: Área de Administrador</h2>
                        <p><b>¡Hola<?php if (isset($nomusu) && ($nomusu != "")) {echo ", ".$nomusu;} ?>!</b><br><br>Nuestra nueva sección de descargas, te permitirá encontrar en un sólo lugar, todos los recursos necesarios de SALVADOR para tu unidad de negocio.<br><br></p>
                        <div class="btn-section"><a href="actualizar" class="btn-default">Actualizar Contenidos</a></div>
                        <br><div class="btn-section"><a href="../cuenta" class="btn-default">Descargar los Contenidos</a></div>
                    </div>
                </div>			  
            </div>
        </div>
        <br><?php include "../../componentes/footer.php"; ?>
    </body>
</html>
<?php ob_end_flush(); ?>