<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$nomusu="";
if (isset($_SESSION["codigo"])) {
    $usuario = $_SESSION["codigo"];
    $nomusu = $_SESSION["usuario"];
    $perusu = $_SESSION["permiso"];
    if($perusu >= 50){
        $usuario = $_SESSION["codigo"];
        $nomusu = $_SESSION["usuario"];
    } else if($perusu < 50){
        header("location: ../../cuenta");    
    }
} else{
    header("../logout.php"); 
}
$alerta = "";
$clase = "";$msg="";
if (isset($_GET['est'])) {
    // id index exists
    $alerta = $_GET['est'];
}
error_reporting(0);

?>
<!DOCTYPE html>
<html>
        <head>
        <title>Salvador Hairdressing - Intranet: Sección de Descargas</title>
        <?php include "../../../componentes/header.php";
              include_once("../../s/analyticstracking.php"); ?>
        <link href="/intranet/descargas/componentes/css/descargas.css" rel="stylesheet">
        <script src="/intranet/descargas/componentes/js/funciones.js"></script>
        </head>

        <body data-spy="scroll" data-target="#navbar-scroll">

        <!-- /.preloader -->
        <div id="top"></div>

        <!-- /.parallax full screen background image -->
        <?php include "../../../componentes/header2.php"; ?>

                            <!-- /.header paragraph -->
                            <div class="landing-text wow fadeInUp">
                                <p>Sección de Descargas</p>
                            </div>				  
                        </div>
                    </div>
                </div> 
            </div> 
        </div>
        <!-- NAVIGATION -->
        <div id="menu">
            <nav class="navbar-wrapper navbar-default" role="navigation">
                <div id="activo" style="float:left;position: absolute;width:20%;">
                    <ul class="nav navbar-nav">
                            <li><a href="#">Usuario: <?php echo $usuario; ?> </a></li>
                        </ul>
                </div>
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-backyard">
                            <span class="sr-only">Intranet: Sección de Descargas</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--<a class="navbar-brand site-name" href="#top"><img src="images/salvador-logo-wh.jpg" alt="logo"></a>-->
                    </div>

                    <div id="navbar-scroll" class="collapse navbar-collapse navbar-backyard navbar-right">
                        <ul class="nav navbar-nav">
                            <li><a href="../actualizar">Intranet: Sección de Descargas</a></li>
                            <li><a href="/intranet/cp">Volver: Panel de Control</a></li>
                            <li><a href="/intranet/logout.php">Salir de la Intranet</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <!-- /.intro section -->
        <div id="main">
            <div class="container"><br>
                <div class="row">

                    <!-- /.intro image -->
                    <div class="col-md-6 intro-pic wow slideInLeft">
                        <img src="/intranet/descargas/componentes/img/Salvador_Descargas2.jpg" alt="image" class="img-responsive">
                    </div>

                    <!-- /.intro content -->
                    <div class="menuMain">
                        <div class="contenedorIngreso">
                    <?php
                    if ($alerta == 1) {
                        $clase = "alert alert-success alert-dismissable fade in";
                        $msg = "Contenido añadido éxitosamente.<br>";
                    } else if ($alerta == 2) {
                        $clase = "alert alert-success alert-dismissable fade in";
                        $msg = "Contenido modificado éxitosamente.<br>";
                    } else if($alerta == 3){
                        $clase = "alert alert-success alert-dismissable fade in";
                        $msg = "Contenido eliminado éxitosamente.<br>";
                    } else if($alerta == 4){
                        $clase = "alert alert-danger alert-dismissable fade in";
                        $msg = "Ocurrió un error durante la última operación :(  - Intenta de nuevo.<br>";
                    } else if($alerta == 5){
                        $clase = "alert alert-warning alert-dismissable fade in";
                        $msg = "Lo sentimos, este formato de archivo no está permitido.<br>";
                    } else if($alerta == 6){
                        $clase = "alert alert-warning alert-dismissable fade in";
                        $msg = "Este archivo no es una imágen.<br>";
                    } else if($alerta == 7){
                        $clase = "alert alert-warning alert-dismissable fade in";
                        $msg = "Uno de los archivos a subir ya se encuentra en el servidor.<br>";
                    } else if($alerta == 8){
                        $clase = "alert alert-warning alert-dismissable fade in";
                        $msg = "Lo sentimos, tu archivo supera el límite de tamaño permitido.<br>";                        
                    } else if($alerta == 8){
                        $clase = "alert alert-warning alert-dismissable fade in";
                        $msg = "Al parecer no se subieron todos los archivos, intenta de nuevo.<br>";                        
                    } else if($alerta == 9){
                        $clase = "alert alert-danger alert-dismissable fade in";
                        $msg = "Hubo un error con la conexión a la Base de Datos.<br>";
                    }
                    if($alerta != ""){
                        echo "<div class='$clase'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        $msg</div>";
                        }
                    ?>
                    <div class="textoIngreso">
                    <h2>ACTUALIZAR CONTENIDOS</h2>
                    <br><p id="landingText1">En esta sección encontrarás todas las opciones necesarias, para el manejo de los archivos que se encuentran en el servidor de <b>SALVADOR DESCARGAS</b>.
                    <br><br><br><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#addreg">Añadir Contenido</button>  <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#modreg">Modificar Contenido</button>  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#elimreg">Eliminar Contenido</button> !--> <br><br></p>
                
                            <!-- COMIENZO DE MODAL: ADD  -->
                            <div id="addreg" class="modal fade" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title"><b>AÑADIR NUEVO CONTENIDO</b></h4>
                                        </div>
                                        <div class="modal-body">
                                            <p>Añadir nuevo archivo, imágen, documento y otros:</p><br>
                                                <form action="../../componentes/multiupload.php" id="formcont" method="post" class="form-horizontal" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-4" for="padre">Departamento:</label>
                                                    <div class="col-sm-6">
                                                    <select name="padre" class="form-control" tabindex="4" onchange="showLoad(this.value, '3a');" required>
                                                        <option value="">-Selecciona una Opción-</option>
                                                        <?php require_once '../../s/nk5w7835.php';
                                                        listarSelectDepartamentos('3a')?>
                                                    </select>
                                                    </div>
                                                </div>
                                                    
                                                    <div class="form-group"><div id="txtHint" class='txt'></div></div>
                                                    <div class="form-group"><div id="txtHint2" class='txt'></div></div>
                                                <input type="hidden" name="tipo" value="3a" />
                                                <?php if(isset($usuario)){echo "<input type='hidden' name='usuario' value='$usuario' />";} ?>
                                                <div class="form-group"> 
                                                    <div class="col-sm-offset-4 col-sm-6">
                                                      <button type="submit" class="botones" name="postcontenido">Subir Archivo</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- FIN DE MODAL: ADD -->
                            
                            <!-- COMIENZO DE MODAL: ELIM  -->
                            <div id="elimreg" class="modal fade" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">ELIMINAR CONTENIDO EN SERVIDOR</h4>
                                        </div>
                                        <div class="modal-body">
                                            <p>¡Advertencia! Una vez eliminado el archivo, este no podrá ser recuperado.</p><br>
                                            <form action="POST" id="formcont" method="post" class="form-horizontal">
                                                <div class="form-group">
                                                    <label class="control-label col-sm-4" for="padre">Departamento:</label>
                                                    <div class="col-sm-6">
                                                    <select name="padre" class="form-control" tabindex="4" onchange="showLoad(this.value, '3c');" required>
                                                        <option value="">-Selecciona una Opción-</option>
                                                        <?php require_once '../../s/nk5w7835.php';
                                                        listarSelectDepartamentos('3c')?>
                                                    </select>
                                                    </div>
                                                </div>
                                                    
                                                    <div class="form-group"><div id="txtHint" class='txt'></div></div>
                                                    <div class="form-group"><div id="txtHint2" class='txt'></div></div>
                                                <input type="hidden" name="tipo" value="3a" />
                                                <?php if(isset($usuario)){echo "<input type='hidden' name='usuario' value='$usuario' />";} ?>
                                                <div class="form-group"> 
                                                    <div class="col-sm-offset-4 col-sm-6">
                                                      <button type="submit" class="botones" name="postcontenido">Eliminar Archivo</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- FIN DE MODAL: ELIM -->
		  
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>

        <?php include "../../../componentes/footer.php"; ?>
    </body>
</html>
<?php ob_end_flush(); ?>