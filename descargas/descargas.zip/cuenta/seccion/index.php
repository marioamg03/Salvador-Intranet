<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$nomusu="";
$perusu = "1";
if (isset($_SESSION["codigo"])) {
    $cod = $_SESSION["codigo"];
    $nom1 = $_SESSION["usuario"];
    $per1 = $_SESSION["permiso"];
}  
$clase = "";
$mensaje = "";
$seccion = "";
$accion = "";
$urlbase = "";
if (isset($_GET['s'])) {
    $seccion = $_GET['s'];
    include '../../../s/rsdh654j686uyj6j65je4j8uepl97.php';
} else if(isset($_GET['p'])) {
    $parametro = $_GET['p'];
    $base = $_GET['base'];
    include '../../../s/rsdh654j686uyj6j65je4j8uepl97.php';
} else if(isset($_GET['accion'])) {
    $accion = $_GET['accion'];
    $urlbase = $_GET['urlbase'];
    $parametro = $_GET['parametro'];
    include '../../../s/rsdh654j686uyj6j65je4j8uepl97.php';
}
?>



















<html xmlns="http://www.w3.org/1999/xhtml"  class="no-js">
    <head>
        <title>Salvador Peluquerías - Área de Descargas</title>
    </head>
    <body>
        <?php
        include '../../../componentes/header.php';
        ?>
        <?php include_once("../../../s/analyticstracking.php"); ?>
        <div class="menuMain">
            <div class="contenedorIngreso">
                    <div id='opcionesDescarga' style='margin-top: 1%;margin-bottom: 1%;'>
                        <div class="textoIngreso">
                                <?php if (isset($_GET['s'])) { echo "<h2>CATEGORIAS DISPONIBLES</h2>"; }?>
                        <div class="cuadroSeccion">
                            <table style="">
                                <thead>
                                    <tr>
                                        <th colspan="3"></th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                    </tr>
                                </tfoot>
                                <tbody>
                                        <?php if (isset($_GET['s'])) {
                                            ListadoCategoria($seccion);
                                        } else if (isset($_GET['p'])){
                                            ListadoContenido($parametro, $base);
                                        }else if(isset($_GET['accion'])){
                                            echo "Tu descarga se encuentra iniciando... Si luego de 5 segundos no comienza, <a href='/descargas/archivos/$urlbase/$parametro/".$accion."'><u><i>haz click aquí</i></u></a>.<br><br><br><a href='?p=$parametro&base=$urlbase' class='botones'>Volver a la sección anterior</a>";
                                        }
                                        ?>
                                </tbody>
                            </table>
                            <?php if (isset($_GET['s'])) {
                                    echo "<a href='/descargas/cuenta/d' class='botones'>Volver a la sección anterior</a>";
                                } else if (isset($_GET['p'])){
                                    echo "<a href='/descargas/cuenta/d/seccion/?s=$base' class='botones'>Volver a la sección anterior</a>";
                                    }
                                ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            include '../../../componentes/footer.php';
            ?>
    </body>
</html>