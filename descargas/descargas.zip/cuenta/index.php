<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$nomusu="";
$perusu = "";
if (isset($_SESSION["codigo"])) {
    $cod = $_SESSION["codigo"];
    $nomusu = $_SESSION["usuario"];
    $perusu = $_SESSION["permiso"];
    $_SESSION["ubicacion"] = "true";
}   else if(isset($_GET['u'])){
    $nomusu = base64_decode($_GET['u']);
    $perusu = base64_decode($_GET['p']);
    $_SESSION["ubicacion"] = "true";
}

$alerta = "";
if (isset($_GET['alerta'])) {
    // id index exists
    $alerta = $_GET['alerta'];
}
$clase = "";
?>
<!DOCTYPE html>
<html>
        <head>
        <title>Salvador Hairdressing - Intranet: Sección de Descargas</title>
        <?php include "../../componentes/header.php";
              include_once("../s/analyticstracking.php"); ?>
        </head>

        <body data-spy="scroll" data-target="#navbar-scroll">

        <!-- /.preloader -->
        <div id="top"></div>

        <!-- /.parallax full screen background image -->
        <?php include "../../componentes/header2.php"; ?>

                            <!-- /.header paragraph -->
                            <div class="landing-text wow fadeInUp">
                                <p>Sección de Descargas</p>
                            </div>				  
                        </div>
                    </div>
                </div> 
            </div> 
        </div>
        <!-- NAVIGATION -->
        <div id="menu">
            <nav class="navbar-wrapper navbar-default" role="navigation">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-backyard">
                            <span class="sr-only">Intranet: Sección de Descargas</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--<a class="navbar-brand site-name" href="#top"><img src="images/salvador-logo-wh.jpg" alt="logo"></a>-->
                    </div>

                    <div id="navbar-scroll" class="collapse navbar-collapse navbar-backyard navbar-right">
                        <ul class="nav navbar-nav">
                            <li><a href="#main">Intranet: Sección de Descargas</a></li>
                            <li><a href="/intranet/descargas/admin">Intranet: Sección de Descargas (Administrador)</a></li>
                            <li><a href="/intranet/cp">Volver: Panel de Control</a></li>
                            <li><a href="/intranet/logout.php">Salir de la Intranet</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <!-- /.intro section -->
                <!-- /.intro section -->
        <div id="main">
            <div class="container"><br><br>
                <div class="row">
<!--<div class="col-md-6 intro-pic wow slideInLeft">-->

                    <!-- /.intro image -->
                    <div class="col-md-6 row package-option" style="padding-top: 0px;">

                    <!-- /.package 1 -->
                    <div class="col-sm-10">
                        <div class="price-box wow fadeInUp">
                            <div class="price-heading text-center">

                                <!-- /.package icon -->
                                <i class="pe-7s-copy-file pe-5x"></i>

                                <!-- /.package name -->
                                <h3>Cantidad de Archivos Disponibles:</h3>
                            </div>

                            <!-- /.price -->
                            <div class="price-group text-center">
                                <!--<span class="dollar">$</span>-->
                                <span class="price"><?php require_once '../s/rsdh654j686uyj6j65je4j8uepl97.php';
                                echo obtenerTotalArchivos(); ?></span>
                                <span class="time">archivos</span>
                            </div><br><br>
                        </div>
                    </div>
                    </div>

                    <!-- /.intro content -->
                    <div class="col-md-6 wow slideInRight">
                    <div class="menuMain">
                        <div class="contenedorIngreso">
                            <?php
                            if ($alerta == 1) {
                                echo "";
                            }
                            ?>
                            <div class="textoIngreso">
                                <h2>SECCIONES DISPONIBLES:</h2>
                                <!--<br><h3>Descargas Disponibles:</h3> !-->
                                <div id='opcionesDescarga' style='margin-top: 1%;margin-bottom: 1%;'>
                                    <div class="cuadroSeccion">
                                        <table style="">
                                            <thead>
                                                <tr>
                                                    <th colspan="3"></th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php ListadoDepartamentos();?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php include "../../componentes/footer.php"; ?>
    </body>
</html>