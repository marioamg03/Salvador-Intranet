<div id="AVA_PIE">
    <div id="cont_footer" class="border-footer" style="width:100%; height:100%; margin:auto; background-image:url(/images/bg_bottom.jpg)">
        <div id="left_part" style="float:left; margin:3% 0 0 0; width:60%; height:60px">       
            <div id="links" style="width:auto; float:left; margin:0px 0 0 40px"><a href="/nosotros.php">Nosotros.</a> <a href="/inspiracion.php">Inspiraci&oacute;n.</a> <a href="/servicios.php">Servicios.</a> <a href="/equipo.php">Equipo.</a> <a href="/ubicaciones.php">Ubicaciones.</a> <a href="/contactenos.php">Cont&aacute;ctenos.</a> <a href="/noticias.php">Novedades.</a></div>
            <div id="linea2" style="width:100%; float:left; margin:5px 0 0 40px" align="left"> Salvador Peluquerías. 2011-2016.<br>&copy; Todos los derechos reservados.</div>
            
        </div>
        <div id="logos" style="width:auto;height:48px;float:left; margin:28px 0 0 15px;">
            <div id="redes_sociales" style="border:0px solid red">
                <a href="https://twitter.com/mundosalvador" target="_blank"><div id="tw"></div></a>
                <a href="http://www.facebook.com/SalvadorPeluquerias" target="_blank"><div id="fb" style="margin:0px 0px 0px 5px"></div></a>
                <a href="http://instagram.com/mundosalvador" target="_blank"><div id="ig" style="margin:0px 0px 0px 5px"></div></a>
                <a href="http://pinterest.com/mundosalvador/" target="_blank"><div id="pin" style="margin:0px 0px 0px 5px"></div></a>
            </div>
        </div>
    </div>
</div> 