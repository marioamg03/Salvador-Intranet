<div class='container' id="line1">
    <section class='color-5'>
        <nav class='cl-effect-5'>
            <ul><div  style="text-align: center;">
                    <a href='/descargas/cuenta'><span data-hover='HOME'>INICIO</span></a>
                    <a href='/descargas/cuenta/d'><span data-hover='DOWNLOAD'>DESCARGAS</span></a>
                    <a href='/descargas/'><span data-hover='LOGOUT'>CERRAR SESIÓN</span></a>
                </div>    
            </ul>
        </nav>
    </section>
</div>