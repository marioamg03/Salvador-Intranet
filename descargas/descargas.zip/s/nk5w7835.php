<?php
function Conectarfb() {
    global $pssw;
    $pssw = "salvasis1";
    $conn = ibase_connect("server:d:\\CorporativoPlus\\nuevo.FDB", "SYSDBA", $pssw);
    if (!$conn) {
        error("Acceso Denegado! <br><a href=\"javascript:window.history.back();\">Volver a la pagina anterior</a>");
        return null;
    }
    return $conn;
}

function addRegistro($titulo, $descripcion, $usu, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    /* AÑADIR REGISTRO DE DEPARTAMENTO */
    $tit2 = strtoupper($titulo);
    $url = strtolower($titulo);
    $url2 = str_replace(' ', '', $url);
    $sql = "INSERT INTO configuraciondescargas (seccionurl, secciontitulo, secciondescripcion, seccionimage, estado) VALUES ('$url2', 'SECCION DE DESCARGAS: " . $tit2 . "', '" . $descripcion . "', 'ND', '1')";
    
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usu, $tipo, $tit2);
        header("location:/intranet/descargas/admin/actualizar/departamento.php?est=1");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/departamento.php?est=4");
        return;
    }
    
}

function modRegistro($titulo, $url, $nnombre, $ndescripcion, $usu, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    /* MODIFICAR REGISTRO DE DEPARTAMENTO */
    $nnom2 = strtoupper($nnombre);
    $sql = "UPDATE configuraciondescargas SET secciontitulo = 'SECCION DE DESCARGAS: $nnom2', secciondescripcion = '$ndescripcion' WHERE seccionurl = '$url';";
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usu, $tipo, $titulo);
        header("location:/intranet/descargas/admin/actualizar/departamento.php?est=2");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/departamento.php?est=4");
        return;
    }
    
}
    
function ocultarRegistro($categoriaelegida, $usuario, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    /* OCULTAR REGISTRO DE DEPARTAMENTO */
    $sql = "UPDATE configuraciondescargas SET estado = 0 WHERE seccionurl = '$categoriaelegida';";
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usuario, $tipo, $categoriaelegida);
        header("location:/intranet/descargas/admin/actualizar/departamento.php?est=3");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/departamento.php?est=4");
        return;
    }
}

function addCategoria($categoria, $depart, $usu, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    
    /* AÑADIR NUEVA CATEGORIA */
    $categoria2 = ucwords(strtolower($categoria));
    $url = strtolower($categoria);
    $url2 = str_replace(' ', '', $url);
    $sql = "INSERT INTO `configuraciondescargaseccion` (idpadre, contenidotitulo, contenidourl, estado) VALUES ('$depart', '" . $categoria2 . "', '". $url2 ."', '1')";
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usu, $tipo, $categoria2);
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=1");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=4");
        return;
    }
    
}

function modCategoria($id, $nnombre, $usuario, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    /* MODIFICAR REGISTRO DE CATEGORIAS */
    $nnombre1 = ucwords(strtolower($nnombre));
    $nnombre2  = strtoupper($nombre);
    $sql = "UPDATE configuraciondescargaseccion SET contenidotitulo = '$nnombre1' WHERE id = $id;";
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usuario, $tipo, $nnombre2);
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=2");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/cateoria.php?est=4");
        return;
    }
    }
    
function ocultarCategoria($categoriaelegida, $usuario, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    /* OCULTAR REGISTRO DE DEPARTAMENTO */
    $sql = "UPDATE configuraciondescargaseccion SET estado = '0' WHERE id = '$categoriaelegida';";
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usuario, $tipo, $categoriaelegida);
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=3");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=4");
        return;
    }
}

function desocultarCategoria($categoriaelegida, $usuario, $tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    /* OCULTAR REGISTRO DE DEPARTAMENTO */
    $sql = "UPDATE configuraciondescargaseccion SET estado = '1' WHERE id = '$categoriaelegida';";
    if (mysqli_query($dbh, $sql)) {
        RegistrarOperacion($usuario, '2d', $categoriaelegida);
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=5");
        return;
    } else {
        die(mysqli_error($dbh));
        header("location:/intranet/descargas/admin/actualizar/categoria.php?est=4");
        return;
    }
}
    
/*function addContenido($nombre, $extension, $tipo, $user, $categoria, $nombre2){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    
    $sql = "INSERT INTO `configuraciondescargascontenido` (idseccion, titulo, url) VALUES ('$categoria', '$nombre', '$nombre2')";
    if (mysqli_query($dbh, $sql)) {
            RegistrarOperacion($user, $tipo, $nombre);
            header("location:/descargas/admin/actualizar/contenido.php?est=1");
            return;
        } else {
            die(mysqli_error($dbh));
            header("location:/descargas/admin/actualizar/contenido.php?est=4");
            return;
        } 
    
    
}*/

function listarSelectDepartamentos($tipo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    $sql = "";
    if($tipo === '2c') {
        $sql = "SELECT A.*, B.ID as 'IDCat', B.estado as 'EstCat', B.contenidotitulo FROM `configuraciondescargas` A INNER JOIN `configuraciondescargaseccion` B ON A.seccionurl = B.idpadre";
    } else if($tipo === '1c'){
        $sql = "SELECT * FROM `configuraciondescargas` where estado = 1";
    } else {
    $sql = "SELECT * FROM `configuraciondescargas`";
    }
        $search = mysqli_query($dbh, $sql) or die(mysqli_error());
        $match = mysqli_num_rows($search);
        if ($match > 0) {
            while ($rw = mysqli_fetch_array($search)) {
                if($tipo === '2c'){
                    $titulo  = $rw['secciontitulo'];
                    $titulo2 = str_replace('SECCION DE DESCARGAS: ', '', $titulo);
                    $titulo3 = $rw['contenidotitulo'];
                    $id = $rw['IDCat'];
                    $estado = $rw['EstCat'];
                    if($estado == '0'){
                        $colorestado  = lightsalmon; 
                        $adicional    = " (Ocultado)";
                    } else if($estado == '1'){
                        $colorestado  = '#ddd'; 
                        $adicional    = "";
                    }
                    echo "<li style='background:$colorestado;'><input type='radio' name='categoria' value='$id' required></input>   $titulo2 - $titulo3 $adicional</li>";
                } else{
                    $titulo  = $rw['secciontitulo'];
                    $titulo2 = str_replace('SECCION DE DESCARGAS: ', '', $titulo);
                    $estado  = $rw['estado'];
                    if ($estado == 0 ){
                        $colorestado  = 'lightsalmon'; 
                        $adicional    = " - (Oculto)";
                    }
                    else {
                        $colorestado  = 'White'; 
                        $adicional    = "";
                    }                    

                    $id = $rw['seccionurl'];
                    if($tipo === '1b'){
                        $titulo2 = $titulo2 . $adicional;
                        echo "<option value='$id' style= 'background-color: $colorestado;'>$titulo2</option>";
                    } else if ($tipo === '1c'){
                        echo "<li><input type='radio' name='categoria' value='$id'></input>   $titulo2</li>";
                    } else if ($tipo === '2b' || $tipo === '3a' || $tipo === '3c'){
                        $titulo2 = $titulo2 . $adicional;
                        echo "<option value='$id' style= 'background-color: $colorestado;'>$titulo2</option>";
                    } /*else if($tipo === '3a'){
                        $titulo2 = $titulo2 . $adicional;
                        $contenido = $rw['contenidotitulo'];
                        echo "<option value='$id;$contenido' style= 'background-color: $colorestado;'>$titulo2 - $contenido</option>";
                    }*/
                }
            }
        }
}

function llenarInputDepartamentos($id){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    $sql = "SELECT * FROM `configuraciondescargas` where seccionurl = '".$id."' AND estado = 1 LIMIT 1";

    $search = mysqli_query($dbh, $sql) or die(mysqli_error());
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        while ($rw = mysqli_fetch_array($search)) {
            $titulo = $rw['secciontitulo'];
            $titulo2 = str_replace('SECCION DE DESCARGAS: ', '', $titulo);
            $descripcion = $rw['secciondescripcion'];
            echo"
            <div class='form-group'>
                <label class='control-label col-sm-4' for='titulonuevo'>Nombre:</label>
                <div class='col-sm-6'> 
                  <input type='text' class='form-control' id='newuser' name='newuser' value='".$titulo2."' required></input>
                </div>
            </div>
            <div class='form-group'>
                <label class='control-label col-sm-4' for='descripcionnuevo'>Descripción:</label>
                <div class='col-sm-6'> 
                  <input type='text' class='form-control' id='newdesc' name='newdesc' value='".$descripcion."' required></input>
                </div>
            </div>
            <input type='hidden' value='".$titulo2."' name='titulo'>
            ";
            }
    }    
}

function mostrarHijosCategoria($id){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    $sql = "SELECT * FROM `configuraciondescargaseccion` where idpadre = '".$id."'";
    $search = mysqli_query($dbh, $sql) or die(mysqli_error());
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        echo "<label class='control-label col-sm-4' for='categoria'>Categoría:</label>
              <div class='col-sm-6'>";?>
              <select name='categoria' class='form-control' tabindex='4' onchange="showModCat(this.value, '2bb');" required>
                    <?php echo "<option value=''>-Selecciona una Categoría-</option>";
        while ($rw = mysqli_fetch_array($search)) {
            $titulo = $rw['contenidotitulo'];
            $idcateg = $rw['id'];
            echo "<option value='$idcateg'>$titulo</option>";
            }
        echo "</select></div>";
    }    
}

function mostrarHijosContenido($id){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    $sql = "SELECT * FROM `configuraciondescargaseccion` where idpadre = '".$id."'";
    $search = mysqli_query($dbh, $sql) or die(mysqli_error());
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        echo "<label class='control-label col-sm-4' for='categoria'>Categoría:</label>
              <div class='col-sm-6'>";?>
              <select name='categoria' class='form-control' tabindex='4' onchange="showModCat(this.value, '3aa');" required>
                    <?php echo "<option value=''>-Selecciona una Categoría-</option>";
        while ($rw = mysqli_fetch_array($search)) {
            $titulo = $rw['contenidotitulo'];
            $idcateg = $rw['id'];
            echo "<option value='$idcateg'>$titulo</option>";
            }
        echo "</select></div>";
    }    
}

function modNombreCategoria($idcat){

    echo"<label class='control-label col-sm-4' for='titulonuevo'>Modificar por:</label>
                <div class='col-sm-6'> 
                  <input type='text' class='form-control' id='titulonuevo' name='titulonuevo' placeholder='Ingresa aquí el nuevo nombre' required></input>
                </div>
            
            <input type='hidden' value='".$idcat."' name='idCategoria'>";
}

function mostrarUpload($id){
    echo "<div class='form-group'>
            <label class='control-label col-sm-3' for='fileToUpload'>Selecciona el archivo a cargar:</label>
            <div class='col-sm-7'>
                <input type='file' class='form-control' name='my_file[]' multiple='multiple' required>
            </div>
        </div>
        <input type='hidden' name='url' value='$id' />";
 }

function RegistrarOperacion($usuario, $tipo, $titulo){
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    date_default_timezone_set('America/Caracas');
    
    $cadena = array(
    "1a" => "AÑADIR DEPARTAMENTO: ",
    "1b" => "MODIFICAR DEPARTAMENTO: ",
    "1c" => "OCULTAR DEPARTAMENTO: ",
    "2a" => "AÑADIR CATEGORÍA: ",
    "2b" => "MODIFICAR CATEGORÍA: ",
    "2c" => "OCULTAR CATEGORÍA: ",
    "2d" => "DESOCULTAR CATEGORIA",
    "3a" => "AÑADIR CONTENIDO: ",
    "3b" => "MODIFICAR CONTENIDO: ",
    "3c" => "OCULTAR CONTENIDO: ");
    
    if($usuario !== ''){
    $sql = "INSERT INTO histoperaciones (usuario, descripcion, fecha) VALUES ('". $usuario ."', '" . $cadena[$tipo] . $titulo ."', '" . date('Y-m-d H:i:s') . "')";
    } else {
    $sql = "INSERT INTO histoperaciones (usuario, descripcion, fecha) VALUES ('N/A', '" . $cadena[$tipo] . $titulo ."', '" . date('Y-m-d H:i:s') . "')";
    }
    if (mysqli_query($dbh, $sql)) {
        
    } else {
        die(mysqli_error($dbh));
    }
}

if (isset($_GET['q'])) {
    $id = $_GET['q'];
    llenarInputDepartamentos($id);
} else if (isset($_GET['w'])){
    $id = $_GET['w'];
    mostrarHijosCategoria($id);
} else if (isset($_GET['ww'])){
    $idcat = $_GET['ww'];
    modNombreCategoria($idcat);
} else if (isset($_GET['x'])){
    $id = $_GET['x'];
    mostrarHijosContenido($id);
//    mostrarUpload($id);
}  else if (isset($_GET['xx'])){
    $id = $_GET['xx'];
    mostrarUpload($id);
} /*else if (isset($_GET['y'])){
    $id = $_GET['y'];
    $extension = $_GET['yy'];
    $tipo = $_GET['y3'];
    $user = $_GET['y4'];
    $categoria = $_GET['y5'];
    $nombre2 = $_GET['y6'];
    addContenido($id, $extension, $tipo, $user, $categoria, $nombre2);
}*/
?>
