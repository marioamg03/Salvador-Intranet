<?php
    function dbconn() {
  	// Create connection
    $link = mysqli_connect('www.salvadorpeluquerias.com', 'sopor907', 'salvasis1', 'sopor907_salvador');
    // Check connection
    return $link;
    }
    function dbconn2() {
  	// Create connection
    $link = mysqli_connect('server', 'sopor907_sistema', 'salvasis1', 'salvador');
    // Check connection
    return $link;
    }
    function dbconn3() {
  	// Create connection
    $link = mysqli_connect('localhost', 'root', '', 'salvador');
    // Check connection
    return $link;
    }
?>