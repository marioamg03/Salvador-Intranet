<?php
function Conectarfb() {
    global $pssw;
    $pssw = "salvasis1";
    $conn = ibase_connect("server:d:\\CorporativoPlus\\nuevo.FDB", "SYSDBA", $pssw);
    if (!$conn) {
        error("Acceso Denegado! <br><a href=\"javascript:window.history.back();\">Volver a la pagina anterior</a>");
        return null;
    }
    return $conn;
}
 
function RegistrarLogin($nombreUsuario, $tipo) {
    require_once "libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    date_default_timezone_set('America/Caracas');
    
    if($tipo == '1'){
    $sql = "INSERT INTO histlogin (descripcion, usuario, fecha) VALUES ('INICIO DE SESION', '" . $nombreUsuario . "', '" . date('Y-m-d H:i:s') . "')";
    } else if ($tipo == '2'){
    $sql = "INSERT INTO histlogin (descripcion, usuario, fecha) VALUES ('INICIO DE SESION: ADMINISTRADOR', '" . $nombreUsuario . "', '" . date('Y-m-d H:i:s') . "')";
    }
    if (mysqli_query($dbh, $sql)) {
        
    } else {
        die(mysqli_error($dbh));
    }
}

function comprobarLogin(){
    $user = $_POST["usuario"];
    $password = $_POST["password"];
    $nombre = strtoupper($user);
    $nombreUsuario = "";
    $permisoUsuario = "";
    
    require_once "s/libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset($dbh, 'utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($dbh));
        exit;
    }
    
    $sql = "SELECT * FROM configuraciondescargasusuarios WHERE codigonombre = '".$nombre."' LIMIT 1;";
    $search = mysqli_query($dbh, $sql);
    $match1 = mysqli_num_rows($search);
    if ($match1 > 0) {
        while ($row = mysqli_fetch_array($search)) {
            $passworddb = $row['password'];
            if($password == $passworddb){

                $usuarioTemp = $row['codigonombre'];
                $nombreUsuarioTemp = $row['nombre'];
                $permisoUsuario = $row['permiso'];    

                $usuario = ucwords($usuarioTemp);
                $nombreUsuario = ucwords($nombreUsuarioTemp);
                $nombreUsuario = ucwords(strtolower($nombreUsuario));

                    if($permisoUsuario >= 50){
                    $tipo = '2';
                    RegistrarLogin($usuario, $tipo);
                    $nomcod = base64_encode($nombreUsuario);
                    $percod = base64_encode($permisoUsuario);

                    $_SESSION["codigo"] = $usuario;
                    $_SESSION["usuario"] = $nombreUsuario;
                    $_SESSION["permiso"] = $permisoUsuario;
                    header("location:/intranet/descargas/admin/index.php?u=$nomcod&p=$percod");
                    return;
                    } else if($permisoUsuario < 50){
                    $tipo = '1';
                    RegistrarLogin($usuario,$tipo);
                    $nomcod = base64_encode($nombreUsuario);
                    $percod = base64_encode($permisoUsuario);

                    $_SESSION["codigo"] = $usuario;
                    $_SESSION["usuario"] = $nomcod;
                    $_SESSION["permiso"] = $percod;
                    header("location:/intranet/descargas/cuenta/index.php?u=$nomcod&p=$percod");
                    return;
                    } // TIPO DE USUARIO
                } // COINCIDENCIA DE CLAVES
                else{
                     /* CONTRASEÑA INCORRECTA */
                    header("Location:/intranet/descargas/index.php?m=3");
                    return;
                }
                }
                
                } else {
                /* USUARIO NO ENCONTRADO */
                header("Location: http://gruposalvador.dyndns.org/descargas/componentes/crearusuario.php?u=$nombre&p=$password");
                return;
        }
}

function ConsultaFBCC() {
    // PARA VALIDACION DE USUARIOS EN CALLCENTER

    $user = $_POST["usuario"];
    $password = $_POST["password"];
    $nombre = strtoupper($user);
    $nombreUsuario = "";
    $permisoUsuario = "";

    $con = Conectarfb();
    $sql = "SELECT CODIGO, NOMBRECOMPLETO, CLAVE, NIVEL FROM usuarios WHERE CODIGO = '$nombre'";
    $result = ibase_query($con, $sql);

    $rawdata = array();
    $i = 0;

    while ($row = ibase_fetch_object($result)) {
        $rawdata[$i] = $row;
        $i++;
    }

    $array = json_encode($rawdata);
    $array2 = json_decode($array);

    $usuarioTemp = $array2[0]->CODIGO;
    $nombreUsuarioTemp = $array2[0]->NOMBRECOMPLETO;
    $permisoUsuario = $array2[0]->NIVEL;

    $usuario = ucwords($usuarioTemp);
    $nombreUsuario = ucwords($nombreUsuarioTemp);
    $nombreUsuario = ucwords(strtolower($nombreUsuario));

    if ($nombreUsuario != "") {
        if($permisoUsuario >= 50){
        $tipo = '2';
        RegistrarLogin($usuario, $tipo);
        $nomcod = base64_encode($nombreUsuario);
        $percod = base64_encode($permisoUsuario);

        $_SESSION["codigo"] = $usuario;
        $_SESSION["usuario"] = $nombreUsuario;
        $_SESSION["permiso"] = $permisoUsuario;
        header("location:/intranet/descargas/admin/index.php?u=$nomcod&p=$percod");
        return;
        } else if($permisoUsuario < 50){
        $tipo = '1';
        RegistrarLogin($usuario,$tipo);
        $nomcod = base64_encode($nombreUsuario);
        $percod = base64_encode($permisoUsuario);

        $_SESSION["codigo"] = $usuario;
        $_SESSION["usuario"] = $nomcod;
        $_SESSION["permiso"] = $percod;
        header("location:/intranet/descargas/cuenta/index.php?u=$nomcod&p=$percod");
        return;
        
        }} else if ($nombreUsuario == "") {
        header("Location:/intranet/descargas");
    }
}

function ListadoDepartamentos(){
    require_once "libfunc.php";
    $dbh = dbconn();
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    $objeto = array(0 => '');
    $i = 0;
    $mensaje = "";
    $sql = "SELECT * FROM `configuraciondescargas` WHERE `estado` = '1' ";
    $search = mysqli_query($dbh, $sql) or die(mysqli_error($dbh));
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        while ($rw = mysqli_fetch_array($search)) {
            $objeto[$i] .= "<tr><td><a href='seccion?s=".$rw['seccionurl']."'><img src='/intranet/descargas/componentes/img/Salvador_S_Logo.png' height='100px' width='100px'></img></a></td>
               <td><a href='seccion?s=".$rw['seccionurl']."'>".$rw['secciontitulo']."</a></td></tr> ";
        }
        foreach ($objeto as $a2) {
                $mensaje = $a2;
            }
        }
        echo $mensaje;
}

function ListadoCategoria($url) {
    require_once "../../../s/libfunc.php";
    $dbh = dbconn();
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    $objeto = array(0 => '');
    $i = 0;
    $mensaje = "";
    $sql = "SELECT * FROM `configuraciondescargaseccion` WHERE `idpadre` = '" . $url . "' ";
    $search = mysqli_query($dbh, $sql) or die(mysqli_error($dbh));
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        while ($rw = mysqli_fetch_array($search)) {
            $objeto[$i] .= "<tr><td style='width: 25%;'><a href='?p=".$rw['contenidourl']."&base=$url'><img src='/intranet/descargas/componentes/img/Salvador_S_Logo.png' height='100px' width='100px'></img></a></td>
               <td><a href='?p=".$rw['contenidourl']."&base=$url'>".$rw['contenidotitulo']."</a></td></tr> ";
        }
               foreach ($objeto as $a2) {
                $mensaje = $a2;
            }
        }
    echo $mensaje."<br>";
}

function ListadoContenido($parametro, $base){
    require_once "../../../s/libfunc.php";
    $dbh = dbconn();
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    $objeto1 = array(0 => '{false}');
    $i = 0;
    $urlbase = "";
    $seccion = strtoupper($parametro);
    $mensaje = "";
    $sql = "SELECT * FROM configuraciondescargascontenido A INNER JOIN configuraciondescargaseccion B on A.idseccion = B.contenidourl where B.contenidourl = '$parametro' AND B.idpadre='".$base."'";
    $search = mysqli_query($dbh, $sql) or die(mysqli_error());
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        echo "<tr><td><b>Archivo</b></td><td><b>Descripción</b></td><td><b>Descargar</b></td></tr>";
        while ($rw = mysqli_fetch_array($search)) {
            $url = $rw['url'];
            $urlbase = $rw['idpadre'];
            $objeto1[$i] = "<tr><td><img src='/intranet/descargas/archivos/$urlbase/$parametro/".$url."' width='150px' height='150px'></img></td><td>".$rw['titulo'] . "</td><td><a href='?accion=".$url."&urlbase=$urlbase&parametro=$parametro'><img src='/descargas/componentes/img/descarga-icono.png' width='75px' height='75px'></img></a></td></tr>";
            $i++;
        }
        foreach ($objeto1 as $a) {
            $mensaje .= "<div class='textoIngreso'>
                                <h2>".$a."</h2></div>";
        }
    }
    echo "<h2>DESCARGA DE: $seccion</h2><br><br>".$mensaje;
}

function RegistrarDescarga($parametro, $urlbase, $url, $usuario){
    require_once "s/libfunc.php";
    $dbh = dbconn();
    mysqli_set_charset('utf8');
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }
    date_default_timezone_set('America/Caracas');

    $sql = "INSERT INTO histlogin (descripcion, usuario, fecha) VALUES ('INICIO DE SESION', '" . $nombreUsuario . "', '" . date('Y-m-d H:i:s') . "')";
    if (mysqli_query($dbh, $sql)) {
        
    } else {
        die(mysqli_error($dbh));
    }
}

function obtenerTotalArchivos(){
   require_once "../s/libfunc.php";
    $dbh = dbconn();
    if (!$dbh) {
        die('Error en Conexión: ' . mysqli_error($con));
        exit;
    }

    $sql = "SELECT count(*) AS TOTAL FROM `configuraciondescargascontenido` LIMIT 1";
    $search = mysqli_query($dbh, $sql) or die(mysqli_error());
    $match = mysqli_num_rows($search);
    if ($match > 0) {
        while ($rw = mysqli_fetch_array($search)) {
            $total = $rw['TOTAL'];
            return $total;
        }
    }
}
?>